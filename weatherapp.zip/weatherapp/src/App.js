import { Box, Container, Typography } from "@mui/material";
import MapDisplay from "./components/MapDisplay";

function App() {
  return (
      <Box display="flex" flexDirection="column" alignItems="center" mt={5}>
        <Typography variant="h4" gutterBottom style={{marginTop:'2rem',marginBottom:'1.7rem'}}>
          Weather App
        </Typography>
        <MapDisplay latitude={0} longitude={0} zoomLevel={5} />

      </Box>
    
  );
}

export default App;
