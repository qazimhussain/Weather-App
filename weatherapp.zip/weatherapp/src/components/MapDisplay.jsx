// src/MapDisplay.js
import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

import { Card, CardContent, Box, Container,Co, Button } from '@mui/material';

import Typography from '@mui/material/Typography';
import CircularProgress from '@mui/material/CircularProgress';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import WeatherDisplay from './WeatherDisplay';



delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-shadow.png',
});

const MapDisplay = ({ latitude, longitude, zoomLevel }) => {
  const [markerPosition, setMarkerPosition] = useState({ lat: latitude, lng: longitude });
  const [weatherData, setWeatherData] = useState(null);
  const [searchLat, setSearchLat] = useState('');
  const [searchLong, setSearchLong] = useState('');
  const [loading, setLoading] = useState(true);
  const [tempType,setTempType]=useState('c')

  const [countryData,setCountryData]=useState({
    code:'',
    country_name:''
  })

  useEffect(()=>{

    
    fetchCountries()
 
  
  },[weatherData])


  // Fetch Countries


  const fetchCountries=async()=>{
    try {
      const response = await axios.get(
        'https://countriesnow.space/api/v0.1/countries/positions',
        {
          headers:{
            'Content-Type':'application/json'
          }
        }
      );

      setCountryData((prev)=>{
        return({
          ...prev,
          country_name:response?.data?.data?.filter(elem=>elem.iso2==prev.code)[0]?.name
        })
      })

      // console.log(response)
    } catch (error) {
      // console.error('Error fetching weather data:', error);

    }
  }


  // Latitude Longitude Form Submission
  const handleSubmit=(e)=>{
    e.preventDefault()

    if(String(searchLat)?.trim()?.length>0 && String(searchLong)?.trim()?.length>0)
      {
        setMarkerPosition({
          lat:searchLat,
          lng: searchLong
        });
        fetchWeatherData(searchLat, searchLong);
    // console.log(searchLat,searchLong)

      }
      else{
    // console.log(searchLat,searchLong)

        toast.error('Please Enter Field')
      }

   

  }

  // Fetch Weather API
  const fetchWeatherData = async (lat, lng) => {
    // console.log(lat,lng)
    const apiKey = '3f239ad28d8ffcd01259d43ece892a2a';
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${apiKey}&units=metric`,
        {
          headers:{
            'Content-Type':'application/json'
          }
        }
      );
      console.log(response)
      setCountryData((prev)=>{
        return({
          ...prev,
          code:response.data.sys.country
        })
      })
      setLoading(false);
      setWeatherData(response.data);
    } catch (error) {
      // console.error('Error fetching weather data:', error);
      setLoading(false);

    }
  };

  // Getting Current Position of user for default setting

  useEffect(() => {
    navigator.geolocation.getCurrentPosition((position) => {
      setMarkerPosition({
        lat: position.coords.latitude,
        lng: position.coords.longitude
      });
      fetchWeatherData(position.coords.latitude, position.coords.longitude);
      setSearchLat(position.coords.latitude)
      setSearchLong(position.coords.longitude)

    });
  }, []);


  // on SHift+ CLick this function will work

  const LocationMarker = () => {
    const map = useMap();

    useEffect(() => {
      if (markerPosition) {
        map.flyTo(markerPosition, 13);
      }
    }, [markerPosition, map]);

    useMapEvents({
      click(event) {
        if (event.originalEvent.shiftKey) {
          const { lat, lng } = event.latlng;
          setMarkerPosition({ lat, lng });
          setSearchLat(lat)
          setSearchLong(lng)
          fetchWeatherData(lat, lng);

        }
      },
    });
    return markerPosition === null ? null : (
      <Marker position={markerPosition}></Marker>
    );
  };

  if (loading) {
    return <CircularProgress />;
  }

  if (!weatherData) {
    return <Typography variant="h6">Failed to fetch weather data</Typography>;
  }

  



  // console.log(weatherData)
 
  


  return (
    <div style={{width:'100%',paddingLeft:'1rem',paddingRight:'1rem'}}>

      <div style={{display:'flex',alignItems:'stretch'}} className='main_box'>

        <div style={{minWidth:'50%'}}>
        <MapContainer center={[markerPosition.lat, markerPosition.lng]} zoom={zoomLevel} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <LocationMarker />
      </MapContainer>
        </div>

        {/* Weather Display Data Component */}

        <WeatherDisplay
         tempType={tempType}
         setTempType={setTempType}
         weatherData={weatherData}
         handleSubmit={handleSubmit}
         markerPosition={markerPosition}
         setSearchLat={setSearchLat}
         searchLat={searchLat}
         setSearchLong={setSearchLong}
         searchLong={searchLong}
         countryData={countryData}
         
         />
        

      </div>
      
     
      <ToastContainer />
      
    </div>
  );
};

export default MapDisplay;



