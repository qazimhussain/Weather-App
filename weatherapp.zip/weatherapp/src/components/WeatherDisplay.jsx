import { Button } from '@mui/material';
import { WiDaySunny, WiNightClear, WiCloudy, WiRain, WiSnow, WiThunderstorm, WiCelsius, WiFahrenheit, WiThermometer, WiRaindrop, WiStrongWind, WiBarometer, WiDaySunnyOvercast, WiNightAltCloudy, WiCloud, WiDayCloudyWindy, WiNightAltCloudyWindy } from 'weather-icons-react';

const weatherIcons = {
    '01d': WiDaySunny,
    '01n': WiNightClear,
    '02d': WiDaySunnyOvercast,
    '02n': WiNightAltCloudy,
    '03d': WiCloud,
    '03n': WiCloud,
    '04d': WiCloudy,
    '04n': WiCloudy,
    '09d': WiRain,
    '09n': WiRain,
    '10d': WiRain,
    '10n': WiRain,
    '11d': WiThunderstorm,
    '11n': WiThunderstorm,
    '13d': WiSnow,
    '13n': WiSnow,
    '50d': WiDayCloudyWindy,
    '50n': WiNightAltCloudyWindy,
  };

function WeatherDisplay(props) {

    const {tempType,
    setTempType,
    weatherData,
    handleSubmit,
    markerPosition,
    setSearchLat,
    searchLat,
    setSearchLong,
    searchLong,
    countryData}=props

    const celsiusToFahrenheit = (celsius) => {
        return (celsius * 9/5) + 32;
      };

  const WeatherIcon = weatherIcons[weatherData.weather[0].icon] 


    return ( 
        <div style={{minWidth:'50%'}}>
        {weatherData && (
     
<div class="container">
<div class="weather__header">
<div class="weather__units">
        <span class={`weather_unit_celsius ${tempType=='c' && 'active'}`} onClick={()=>{setTempType('c')}}><WiCelsius size={40}/></span>
        <span class={`weather_unit_farenheit ${tempType=='f' && 'active'}`} onClick={()=>{setTempType('f')}}><WiFahrenheit size={40}/></span>
    </div>
   
   
</div>

<div className="weather_main_info" style={{display:'flex'}}>

<form class="weather__search" onSubmit={(e)=>handleSubmit(e)}>
      <div style={{display:'flex',alignItems:'flex-start',flexDirection:'column'}}>

      
      <div style={{display:'flex',gap:'10px',flexDirection:'column',alignItems:'flex-start',justifyContent:'flex-start'}}>
        <div className="">
          <label htmlFor="" >Latitude</label>
      <input type="text" style={{marginTop:'.5rem',marginBottom:'.5rem'}} placeholder="" class="weather__searchform" value={searchLat} onChange={(e)=>setSearchLat(e.target.value)}/>
      
      {
            searchLat?.length==0 && <span style={{fontSize:'.7rem',color:'red',display:'block',marginTop:'.4rem'}}>This Field is required</span>
          }

        </div>
        <div className="">
          <label htmlFor="" >Longitude</label>
          <input type="text" style={{marginTop:'.5rem'}} value={ searchLong} placeholder="" class="weather__searchform" onChange={(e)=>setSearchLong(e.target.value)}/>
          {
            searchLong?.length==0 && <span style={{fontSize:'.7rem',color:'red',display:'block',marginTop:'.4rem'}}>This Field is required</span>
          }

        </div>

      

      </div>
      <Button color='white' type='submit' style={{marginTop:".9rem"}} variant='light'>Submit</Button>

      </div>
      
    </form> 
<div class="weather__body">
    <h1 class="weather__city" style={{marginBottom:'.7rem'}}>{weatherData.name} {countryData?.country_name && ', '+ countryData?.country_name}</h1>
   
    <div class="weather__forecast">{weatherData.weather[0].main}</div>
    <div class="weather__icon">
    <WeatherIcon size={64} />
    </div>
    <p class="weather__temperature">
      <span>{tempType=='c'?
      Math.round(weatherData.main.temp):
      celsiusToFahrenheit(Math.round(weatherData.main.temp))}</span>
      {
        tempType=='c'?
        <WiCelsius size={50}/>:
        <WiFahrenheit size={50}/>
      }
     
    </p>
  
</div>
</div>

<div class="weather__info">
    <div class="weather__card">
      <WiThermometer size='35'/>
        <div>
            <p>Real Feel</p>
            <p class="weather__temperature">
      <span>
      {
        tempType=='c'?
        Math.round(weatherData.main.feels_like):
        celsiusToFahrenheit(Math.round(weatherData.main.feels_like))
      }
      </span>
      {
        tempType=='c'?
        <WiCelsius size={30}/>:
        <WiFahrenheit size={30}/>
      }
    </p>
        </div>
    </div>
    <div class="weather__card">
       <WiRaindrop size='35'/>
        <div>
            <p>Humidity</p>
            <p class="weather__humidity">
            {weatherData.main.humidity}%</p>
        </div>
    </div>
    <div class="weather__card">
        <WiStrongWind size='35'/>
        <div>
            <p>Wind</p>
            <p class="weather__wind">
            {parseFloat(weatherData.wind.speed).toFixed(2)} m/s</p>
        </div>
    </div>
    <div class="weather__card">
    <WiBarometer size='35'/>

                <div>
                    <p>Pressure</p>
                    <p class="weather__pressure">{Math.round(weatherData.main.pressure)} hPa</p>
                </div>
            </div>
    
</div>
</div>
      )}

        </div>
     );
}

export default WeatherDisplay;